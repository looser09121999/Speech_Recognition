# SpeechRecognition

Python Speech Recognition 

The easiest way to install this is using pip install SpeechRecognition.

The first software requirement is Python 2.6, 2.7, or Python 3.3+. This is required to use the library. At the moment 3.7 not working

Linux Based Operating Systems
sudo apt-get install python-pyaudio python3-pyaudio

Windows
https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio
